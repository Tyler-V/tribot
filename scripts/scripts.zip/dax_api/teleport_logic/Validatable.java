package scripts.dax_api.teleport_logic;


public interface Validatable {
    boolean canUse();
}
