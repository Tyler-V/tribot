package scripts.dax_api.api_lib;

public class DaxConfigs {

    public static boolean logging = true;

}
