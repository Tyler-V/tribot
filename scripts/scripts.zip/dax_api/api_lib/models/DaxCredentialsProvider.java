package scripts.dax_api.api_lib.models;

public abstract class DaxCredentialsProvider {

    public abstract DaxCredentials getDaxCredentials();

}
