package scripts.dax_api.engine.models;

public enum WalkTaskType {
    COLLISION_BLOCKING,
    DISCONNECTED_PATH,
    NORMAL_PATH_HANDLING,
    PATH_TOO_FAR,

}
