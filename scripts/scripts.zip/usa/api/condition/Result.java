package scripts.usa.api.condition;

public enum Result {
	ERROR,
	INTERRUPTED,
	SUCCESS,
	TIMEOUT;
}
