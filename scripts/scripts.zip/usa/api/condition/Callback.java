package scripts.usa.api.condition;

public interface Callback {

	Status getStatus();

}
