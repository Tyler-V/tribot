package scripts.usa.api.condition;

public enum Status {
	INTERRUPT,
	SUCCESS,
	RESET,
	CONTINUE;
}
