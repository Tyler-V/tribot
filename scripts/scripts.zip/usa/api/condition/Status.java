package scripts.usa.api.condition;

public enum Status {
	ERROR,
	INTERRUPT,
	SUCCESS,
	RESET,
	CONTINUE;
}
