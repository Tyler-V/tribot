package scripts.usa.api.framework.task;

public interface Task {

	public boolean validate();

	public void execute();

}
