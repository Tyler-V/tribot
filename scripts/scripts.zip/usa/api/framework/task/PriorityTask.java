package scripts.usa.api.framework.task;

public interface PriorityTask extends Task {

}
