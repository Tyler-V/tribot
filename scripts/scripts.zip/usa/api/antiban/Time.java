package scripts.usa.api.antiban;

public enum Time {

	START, END, ACTION, COMBAT;

}
