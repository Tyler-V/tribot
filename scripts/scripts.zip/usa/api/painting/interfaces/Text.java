package scripts.usa.api.painting.interfaces;

public interface Text {

    String getString();

}