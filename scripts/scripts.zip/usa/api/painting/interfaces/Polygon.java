package scripts.usa.api.painting.interfaces;

public interface Polygon {

	java.awt.Polygon getPolygon();

}
