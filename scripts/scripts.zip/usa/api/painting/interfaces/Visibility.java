package scripts.usa.api.painting.interfaces;

public interface Visibility {

    boolean isVisible();

}
