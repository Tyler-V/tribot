package scripts.usa.api2007.teleporting.interfaces;

public interface TeleportOption {

	boolean canUse();
	
}
