package scripts.usa.api2007.grand_exchange;

/**
 * TYPE represents the three possible states of a Grand Exchange window.
 */
public enum WindowType {

	BUY, SELL, EMPTY;

}