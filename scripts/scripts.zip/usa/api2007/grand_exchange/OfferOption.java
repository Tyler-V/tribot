package scripts.usa.api2007.grand_exchange;

/**
 * OFFER represents the options for creating a new offer.
 */
public enum OfferOption {

	BUY,
	SELL;

}
