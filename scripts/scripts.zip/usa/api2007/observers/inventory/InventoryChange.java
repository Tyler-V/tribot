package scripts.usa.api2007.observers.inventory;

public enum InventoryChange {
	INCREASE,
	DECREASE
}
