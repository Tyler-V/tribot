package scripts.usa.api2007.worlds;

public enum WorldSorting {
	PLAYER_COUNT_LOWEST,
	PLAYER_COUNT_HIGHEST,
	WORLD_NUMBER_LOWEST,
	WORLD_NUMBER_HIGHEST;
}
