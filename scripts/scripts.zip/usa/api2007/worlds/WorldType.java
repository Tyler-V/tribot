package scripts.usa.api2007.worlds;

public enum WorldType {

	FREE,
	MEMBERS

}
