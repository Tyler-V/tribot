package scripts.usa.api2007;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import org.tribot.api.types.generic.Filter;
import org.tribot.api2007.GameTab;
import org.tribot.api2007.types.RSItem;

import scripts.usa.api.condition.Condition;

public class Inventory extends org.tribot.api2007.Inventory {

	public static boolean open() {
		if (GameTab.getOpen() == GameTab.TABS.INVENTORY)
			return true;
		GameTab.open(GameTab.TABS.INVENTORY);
		return Condition.wait(() -> GameTab.getOpen() == GameTab.TABS.INVENTORY);
	}

	public static int getSpace() {
		return 28 - Inventory.getAll().length;
	}

	public static int getCount(List<String> names) {
		return Inventory.getCount(names.toArray(new String[names.size()]));
	}

	public static int getCount(RSItem item) {
		return item == null ? 0 : Inventory.getCount(item.getID());
	}

	public static int getCount(RSItem... items) {
		int count = 0;
		List<RSItem> list = Arrays.stream(items).distinct().collect(Collectors.toList());
		for (RSItem item : list)
			count += getCount(item);
		return count;
	}

	public static int getCount(Filter<RSItem> filter) {
		RSItem[] items = Inventory.find(filter);
		if (items.length == 0)
			return 0;

		return getCount(items[0]);
	}

	public static boolean drop(int amount, String... names) {
		RSItem[] items = Inventory.find(names);
		if (items.length == 0)
			return false;
		final int count = Inventory.getCount(names);
		if (items[0].click("Drop"))
			Condition.wait(() -> count != Inventory.getCount(names));
		return count != Inventory.getCount(names);
	}
}
