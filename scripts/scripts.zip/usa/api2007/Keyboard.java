package scripts.usa.api2007;

public class Keyboard extends org.tribot.api.input.Keyboard {

	public static void typeSend(int number) {
		typeSend("" + number);
	}
}
