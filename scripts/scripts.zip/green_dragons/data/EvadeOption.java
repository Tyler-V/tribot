package scripts.green_dragons.data;

public enum EvadeOption {
	THREAT_DETECTED,
	SKULLED_THREAT_DETECTED,
	UNDER_ATTACK
}
